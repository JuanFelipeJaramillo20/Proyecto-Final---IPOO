/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package Interfaz;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import mundo.Usuario;

/**
 *
 * @author juanf
 */
public class Registro extends JPanel implements MouseListener{
    
    private Ventana ventana;
    private Image fondo;
    private String usuario = "";
    private String password = "";
    private String nombres = "";
    private String apellidos = "";
    private Usuario temp = null;

    public Registro(Ventana ventana) {
        this.ventana = ventana;
        fondo = new ImageIcon(getClass().getResource("/imagenes/Registroymenuprincipalusuario.png")).getImage();
        setSize(350,756);
        setLayout(null);
        addMouseListener(this);
        setLocation(0,0);
        setVisible(false);
        
    }
    
    public void paint(Graphics g){
        super.paint(g);
        Font f = new Font("Lucida Calligraphy", Font.ITALIC, 18);
        g.setFont(f);
        g.setColor(Color.BLACK);
        g.drawString("Ingrese su(s) nombre(s):",65, 100);
        textField(70, 105, 200, 22, g);
        g.setColor(Color.BLACK);
        g.drawString("Ingrese sus apellidos:", 65, 170);
        textField(70, 175, 200, 22, g);
        g.setColor(Color.BLACK);
        g.drawString("Ingrese su nombre de usuario:", 20, 240);
        textField(70, 245, 200, 22, g);
        g.setColor(Color.BLACK);
        g.drawString("Ingrese su contraseña:", 65, 310);
        textField(70, 315, 200, 22, g);
        boton(90, 375, 150, 30, g);
        g.setColor(Color.BLACK);
        g.drawString("Registrarse", 110, 395);
        rellenarNombres(g);
        rellenarApellidos(g);
        rellenarPassword(g);
        rellenarUsuario(g);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(fondo, 0, 0,this.getWidth(),this.getHeight(), null);
    }
    
    public void boton(int x, int y, int ancho, int alto, Graphics g){
        Color amarillo = new Color(254, 242, 113);
        g.setColor(amarillo);
        g.fillRect(x, y, ancho, alto);
    }
    
    public void escribirString(String texto, Graphics g, int y){
        Font f = new Font("Lucida Calligraphy", Font.ITALIC, 18);
        g.setFont(f);
        g.drawString(texto, 360, y);
    }
    
    public void textField(int x, int y, int ancho, int alto, Graphics g){
        g.setColor(Color.WHITE);
        g.fillRect(x, y, ancho, alto);
    }

    public void rellenarUsuario(Graphics g){
        Font f = new Font("Lucida Calligraphy", Font.ITALIC, 12);
        g.setColor(Color.BLACK);
        g.setFont(f);
        g.drawString(usuario, 120, 260);
    }
    
    public void rellenarPassword(Graphics g){
        Font f = new Font("Lucida Calligraphy", Font.ITALIC, 12);
        g.setFont(f);
        String contrasena = "";
        for(int i = 0 ; i < password.length() ; i++){
            contrasena += "*";
        }
        g.drawString(contrasena, 120, 330);
    }
    
    public void rellenarNombres(Graphics g){
        Font f = new Font("Lucida Calligraphy", Font.ITALIC, 12);
        g.setFont(f);
        g.drawString(nombres, 125, 120);
    }
    
    public void rellenarApellidos(Graphics g){
       Font f = new Font("Lucida Calligraphy", Font.ITALIC, 12);
        g.setFont(f);
        g.drawString(apellidos, 120, 190); 
    }
    @Override
    public void mouseClicked(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        
        
        if( x >= 70 && x <= 270 && y >= 105 && y <= 127 ){
            nombres = JOptionPane.showInputDialog("Ingrese su(s) nombre(s)");
            repaint();
        }
        if( x >= 70 && x <= 270 && y >= 175 && y <= 197 ){
            apellidos = JOptionPane.showInputDialog("Ingrese sus apellidos:");
            repaint();
        }
        if( x >= 70 && x <= 270 && y >= 245 && y <= 267 ){
            do {                
                usuario = JOptionPane.showInputDialog("Ingrese su nombre de usuario:");
            } while (ventana.principal.validarUserName(usuario));
            repaint();
        }    
        if( x >= 70 && x <= 270 && y >= 315 && y <= 337 ){
            password = JOptionPane.showInputDialog("Ingrese su contraseña:");
            repaint();
        }
        if ( x >= 90 && x <= 240 && y >= 375 && y <= 405){
           ventana.principal.crearUsuarioNoAfiliado(usuario, nombres, apellidos, password);
           ventana.primerMenu.setVisible(true);
            setVisible(false);
        }
    
    }

    @Override
    public void mousePressed(MouseEvent e) { }
    @Override
    public void mouseReleased(MouseEvent e) { }
    @Override
    public void mouseEntered(MouseEvent e) { }
    @Override
    public void mouseExited(MouseEvent e) { }
    
    
}
