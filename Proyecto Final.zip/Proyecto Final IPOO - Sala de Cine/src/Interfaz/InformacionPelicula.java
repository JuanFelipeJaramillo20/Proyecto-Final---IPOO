/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package Interfaz;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import mundo.*;

public class InformacionPelicula extends JPanel implements MouseListener{

    private Ventana ventana;
    private Image fondo;
    private Pelicula pelicula;
    
    public InformacionPelicula( Ventana ventana){
        this.ventana = ventana;
        this.pelicula = null;
        fondo = new ImageIcon(getClass().getResource("/imagenes/Infopeliculasyboletos.png")).getImage();
        setSize(1080,768);
        setLayout(null);
        addMouseListener(this);
        setLocation(0,0);
        setVisible(false);
        
    }
    
    public void setPelicula(Pelicula pelicula){
        this.pelicula = pelicula;
        repaint();
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font f = new Font("Lucida Calligraphy", Font.ITALIC, 18);
        g.setFont(f);
        g.setColor(Color.WHITE);
        g.drawString("(También para reservar!)", 246, 408);
        g.drawString(pelicula.getSinapsis(), 352, 160);
        g.drawString(pelicula.getClasificacion(), 985, 86);
        g.setColor(Color.BLACK);
        g.fillRect(850, 86, 129, 35);
        g.setColor(Color.WHITE);
        g.drawString("Clasificación:", 820, 86);
        
        Font f1 = new Font("Lucida Calligraphy", Font.ITALIC, 14);
        g.setFont(f1);
        g.setColor(Color.WHITE);
        g.drawString(pelicula.getTrailer(), 435, 358);
        escribirOpiniones(g);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(fondo, 0, 0, 1080, 730, null);
        g.drawImage(pelicula.getAfiche().getImage(), 37, 99, 190, 272, null);
    }
    
    public void escribirOpiniones(Graphics g){
        Font f = new Font("Lucida Calligraphy", Font.ITALIC, 14);
        g.setFont(f);
        g.setColor(Color.BLACK);
        
        Random number = new Random();
        int number1 = 0;
        int number2 = 0;
        int number3 = 0;
        if(pelicula.getOpiniones() != null){
            if(pelicula.getOpiniones().size() > 3){
                for (int i = 0; i < pelicula.getOpiniones().size(); i++) {
                do {                    
                    number1 = number.nextInt(pelicula.getOpiniones().size()  );
                    number2 = number.nextInt(pelicula.getOpiniones().size()  );
                    number3 = number.nextInt(pelicula.getOpiniones().size()  );
                } while (number1 == number2 || number1 == number3 || number2 == number3);
                }
            }else{
                number1 = 0;
                number2 = 1;
                number3 = 2;
            }
            if(pelicula.getOpiniones().size() >= 1){
                if( number1 <= pelicula.getOpiniones().size() && pelicula.getOpiniones().get(number1) != null){
                g.drawString(pelicula.getOpiniones().get(number1), 50, 530);
            }
            if ( pelicula.getOpiniones().size() >= 2) {
                if (pelicula.getOpiniones().get(number2) != null) {
                    g.drawString(pelicula.getOpiniones().get(number2), 415, 530);
                }
            }
            if ( pelicula.getOpiniones().size() >= 3) {
                if (pelicula.getOpiniones().get(number3) != null) {
                    g.drawString(pelicula.getOpiniones().get(number3), 760, 530);
                }
                
            }
            }
            
        }
        
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        
        if ( x >= 25 && x <= 230 && y >= 380 && y <= 415 ) {
            ventana.comprarYReservar.setPelicula(pelicula);
            ventana.comprarYReservar.llenarListaFunciones();
            ventana.comprarYReservar.listaFuncionesPorHora();
            ventana.comprarYReservar.setNombreFuncion(seleccionarFuncion());
            ventana.comprarYReservar.setFuncion();
            setVisible(false);
            ventana.comprarYReservar.setVisible(true);
            
        }
        if ( x >= 361 && x <= 701 && y >= 697 && y <= 741 ) {
            String opinion = Utilerias.leerString("Ingresa tu opinión (corta por favor para motivos de impresión):");
            pelicula.agregarOpinion(opinion);
            repaint();
        }
    }
    public String seleccionarFuncion(){
        return Utilerias.seleccionDesplegable(ventana.comprarYReservar.getHoraFunciones(), "Seleccione la función:");
    }


    @Override
    public void mousePressed(MouseEvent e) {    }

    @Override
    public void mouseReleased(MouseEvent e) {    }

    @Override
    public void mouseEntered(MouseEvent e) {    }

    @Override
    public void mouseExited(MouseEvent e) {    }
    
}
