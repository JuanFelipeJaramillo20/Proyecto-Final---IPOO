/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package Interfaz;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseListener;
import java.security.Principal;
import javax.swing.JPanel;
import mundo.Afiliado;
import mundo.NoAfiliado;
import mundo.Sala;

/**
 *
 * @author juanf
 */
public class Estadisticas extends JPanel{

    
    private Ventana ventana;
    
    public Estadisticas(Ventana ventana) {
        this.ventana = ventana;
        setBackground(Color.white);
        setSize(1080,768);
        setLayout(null);
        setLocation(0, 0);
        setVisible(false);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g); 
        Font f = new Font("Lucida Calligraphy", Font.ITALIC, 18);
        g.setFont(f);
        g.setColor(Color.BLACK);
        g.drawString("Sillas disponibles vs sillas vendidas", 20, 45);
        g.drawLine(20, 55, 20, 220);
        int anchoVendidas = 0 + (ventana.principal.boletasVendidas()) * 5;
        g.fillRect(20, 70, anchoVendidas, 30);
        int anchoDisponibles = ventana.principal.boletasDisponibles() * 2;
        g.fillRect(20, 160, anchoDisponibles, 30);
        g.drawString("Boletas Disponibles: " + ventana.principal.boletasDisponibles() + " - Boletas vendidas: " + ventana.principal.boletasVendidas(), 35, 230);
        
        g.drawString("Salas disponibles vs salas ocupadas", WIDTH, WIDTH);
        int libres = 0;
        int ocupadas = 0;
        for (int i = 0; i < ventana.principal.getListaDeSalas().length; i++) {
            if(ventana.principal.getListaDeSalas()[i].isOcupada()){
                ocupadas++;
            }else{
                libres++;
            }
        }
        int anchoLibres = libres*5;
        int anchoOcupadas = ocupadas*5;
        g.drawLine(20, 260, 20, 425);
        g.fillRect(20, 275, anchoLibres, 30);
        g.fillRect(20, 355, anchoOcupadas, 30);
        g.drawString("Salas disponibles: " + libres + " - Salas ocupadas: " + ocupadas, 25, 440);
        
        int cantidadAfiliados=0;
        int cantidadNoAfiliados =0;
        
        for(int i = 0 ; i < ventana.principal.getListaDeUsuarios().size() ; i++){
            if(ventana.principal.getListaDeUsuarios().get(i) instanceof Afiliado){
                cantidadAfiliados++;
            }else if(ventana.principal.getListaDeUsuarios().get(i) instanceof NoAfiliado){
                cantidadNoAfiliados++;
            }
        }
        int anchoAfiliados = cantidadAfiliados*5;
        int anchoNoAfiliados = cantidadNoAfiliados*5;
        g.drawString("Cantidad afilados vs no afiliados:", 20, 500);
        g.drawLine(20, 520, 20, 740);
        g.fillRect(20, 550, anchoAfiliados, 30);
        g.fillRect(20, 600, anchoNoAfiliados, 30);
        g.drawString("Usuarios afiliados: " + cantidadAfiliados + " - Usuarios no Afiliados: " + cantidadNoAfiliados, 20, 760);
        }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    
}
