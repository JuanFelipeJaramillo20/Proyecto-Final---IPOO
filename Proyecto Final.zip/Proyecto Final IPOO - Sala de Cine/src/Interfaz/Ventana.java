/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package Interfaz;

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JFrame;
import mundo.ProyectoFinalIPOOSalaDeCine;

/**
 *
 * @author juanf
 */
public class Ventana extends JFrame{
    
    ProyectoFinalIPOOSalaDeCine principal;
    PrimerMenu primerMenu;
    Registro registro;
    Login login;
    ConsultaPeliculas consultaPeliculas;
    MenuUsuario menuUsuario;
    ComprarYReservar comprarYReservar;
    InformacionPelicula informacionPelicula;
    Estadisticas estadisticas;
    
    public Ventana() {
        
        super("<<< Cinema Univalle >>>");
        setSize(350, 756 );
        setResizable(true);
        setPreferredSize(new Dimension(1080, 768));
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(true);
        
        primerMenu = new PrimerMenu(this);
        add(primerMenu);
        principal = new ProyectoFinalIPOOSalaDeCine();
        setVisible(true);
        
        //Panel Registro
        registro = new Registro(this);
        add(registro);
        
        //Panel Login
        login = new Login(this);
        add(login);
        
        //Panel Menu Usuario
        menuUsuario = new MenuUsuario(this);
        add(menuUsuario);
        
        //Panel Consulta Películas
        consultaPeliculas = new ConsultaPeliculas(this);
        add(consultaPeliculas);
        
        //Panel Información Pelicula
        informacionPelicula = new InformacionPelicula(this);
        add(informacionPelicula);
        
        //Panel Comprar y Reservar
        comprarYReservar = new ComprarYReservar(this);
        add(comprarYReservar);
        
        //Estadisticas
        estadisticas = new Estadisticas(this);
        add(estadisticas);
    }

    @Override
    public void repaint(long time, int x, int y, int width, int height) {
        setSize(1080, 768);
        super.repaint(time, x, y, width, height); 
        
    }
    
    public static void main(String[] args) {
        Ventana ventanaPrincipal = new Ventana();
    }
    
}
