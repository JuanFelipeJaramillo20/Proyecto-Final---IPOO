/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package Interfaz;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 *
 * @author juanf
 */
public class ConsultaPeliculas extends JPanel implements MouseListener{
    
    Ventana ventana;
    private Image fondo;
    private Image[] afiches;

    public ConsultaPeliculas(Ventana ventana) {
        this.ventana = ventana;
        fondo = new ImageIcon(getClass().getResource("/imagenes/ConsultaPeliculas.png")).getImage();
        setSize(1080,768);
        setLayout(null);
        addMouseListener(this);
        setLocation(0,0);
        setVisible(false);
        afiches = new Image[4];
        cargarAfiches();
    }

    public void cargarAfiches(){
        for (int i = 0; i < afiches.length; i++) {
            if(ventana.principal.getListaDePeliculas()[i] != null){
                if(ventana.principal.getListaDePeliculas()[i].getAfiche() != null){
                    afiches[i] = ventana.principal.getListaDePeliculas()[i].getAfiche().getImage();
                }
            }
            
        }
    }
    
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        if (afiches[0] != null) {
            g.drawImage(afiches[0], 41, 384, 187, 274, null);
        }
        if (afiches[1] != null) {
            g.drawImage(afiches[1], 306, 384, 187, 274, null);
        }
        if (afiches[2] != null) {
            g.drawImage(afiches[2], 572, 384, 187, 274, null);
        }
        if (afiches[3] != null) {
            g.drawImage(afiches[3], 837, 384, 187, 274, null);
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(fondo, 0, 0, 1080,768,null);
        if (afiches[0] != null) {
            g.drawImage(afiches[0], 41, 384, 187, 274, null);
        }
        if (afiches[1] != null) {
            g.drawImage(afiches[1], 306, 384, 187, 274, null);
        }
        if (afiches[2] != null) {
            g.drawImage(afiches[2], 572, 384, 187, 274, null);
        }
        if (afiches[3] != null) {
            g.drawImage(afiches[3], 837, 384, 187, 274, null);
        }
    }
    
    

    @Override
    public void mouseClicked(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        
        if ( x >= 41 && x <= 228 && y >= 384 && y <= 658 ) {
            if(ventana.principal.getListaDePeliculas()[0] != null){
                setVisible(false);
                ventana.informacionPelicula.setPelicula(ventana.principal.getListaDePeliculas()[0]);
                ventana.informacionPelicula.setVisible(true);   
                
            }
        }
        if ( x >= 306 && x <= 493 && y >= 384 && y <= 658 ) {
            if (ventana.principal.getListaDePeliculas()[1] != null) {
                setVisible(false);
                ventana.informacionPelicula.setPelicula(ventana.principal.getListaDePeliculas()[1]);
                ventana.informacionPelicula.setVisible(true);
            }
            
        }
        if ( x >= 572 && x <= 759 && y >= 384 && y <= 658 ) {
            if (ventana.principal.getListaDePeliculas()[2] != null) {
                setVisible(false);
                ventana.informacionPelicula.setPelicula(ventana.principal.getListaDePeliculas()[2]);
                ventana.informacionPelicula.setVisible(true);   
            }
        }
        if ( x >= 837 && x <= 1024 && y >= 384 && y <= 658 ) {
            if (ventana.principal.getListaDePeliculas()[3] != null) {
                setVisible(false);
                ventana.informacionPelicula.setPelicula(ventana.principal.getListaDePeliculas()[3]);
                ventana.informacionPelicula.setVisible(true);
            }
            
        }
    }

    @Override
    public void mousePressed(MouseEvent e) { }
    @Override
    public void mouseReleased(MouseEvent e) { }
    @Override
    public void mouseEntered(MouseEvent e) { }
    @Override
    public void mouseExited(MouseEvent e) { }
    
    
}
