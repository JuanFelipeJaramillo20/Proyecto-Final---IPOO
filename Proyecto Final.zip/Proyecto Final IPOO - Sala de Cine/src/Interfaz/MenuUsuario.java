/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package Interfaz;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.Calendar;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import jdk.jshell.execution.Util;
import mundo.Administrador;
import mundo.Afiliado;
import mundo.Pelicula;
import mundo.Supervisor;
import mundo.Usuario;
import mundo.Utilerias;

/**
 *
 * @author juanf
 */
public class MenuUsuario  extends JPanel implements  MouseListener{

    private Usuario usuarioActual;
    Ventana ventana;
    private Image fondo;
    private String userName;
    boolean acepto;
    String nomArchivo;
    String nomArchivoCopiado;


    
    public MenuUsuario(Ventana ventana) {
        this.ventana = ventana;
        fondo = new ImageIcon(getClass().getResource("/imagenes/Registroymenuprincipalusuario.png")).getImage();
        setSize(350,756);
        setLocation(0,0);
        setLayout(null);
        addMouseListener(this);
        setVisible(false);
        setUserName();
        nomArchivo = nomArchivoCopiado = "";
        File directorio = new File("img_seleccionadas");
        if (!directorio.exists()) {
            directorio.mkdirs();//crear la carpeta para almacenar las imagenes seleccionadas
        }

    }

    public Usuario getUsuarioActual() {
        return usuarioActual;
    }
       
    public String getFecha() {
        String fecha = "";
        Calendar cal = Calendar.getInstance();//obtener una instancia del calendario del sistema
        int dia = cal.get(Calendar.DATE);
        int mes = cal.get(Calendar.MONTH) + 1;//Para Java los meses comienza cero, es decir Enero es 0, Febrero 1, .... Diciembre 11
        int year = cal.get(Calendar.YEAR);

        if (dia < 10) {
            fecha += "0" + dia + "_";
        } else {
            fecha += dia + "_";
        }

        if (mes < 10) {
            fecha += "0" + mes + "_";
        } else {
            fecha += mes + "_";
        }

        fecha += year + "_";
        
        fecha += cal.get(Calendar.HOUR_OF_DAY) + "_";
        int min = cal.get(Calendar.MINUTE);
        int seg = cal.get(Calendar.SECOND);
        
        if (min < 10) {
            fecha += "0" + min + "_";
        } else {
            fecha += min + "_";
        }
        
        if (seg < 10) {
            fecha += "0" + seg;
        } else {
            fecha += seg;
        }

        return fecha;
    }

    
    public void setUsuario(Usuario user){
        usuarioActual = user;
    }
    
    public void setUserName(){
        if(usuarioActual == null){
            userName = "Invitado";
        }else{
            userName = usuarioActual.getNombre();
        }
        repaint();
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font f = new Font("Lucida Calligraphy", Font.ITALIC, 18);
        g.setFont(f);
        g.setColor(Color.BLACK);
        g.drawString("Bienvenido, "+ userName, 30, 100);
        Font f1 = new Font("Lucida Calligraphy", Font.ITALIC, 14);
        g.setFont(f1);
        
        boton(20, 130, 295, 22, g);
        g.setColor(Color.WHITE);
        g.drawString("Consultar películas/comprar Tiquetes", 25, 145);
        
        boton(20, 170, 295, 22, g);
        g.setColor(Color.WHITE);
        g.drawString("Modificar datos personales", 65, 185);
        
        boton(20, 210, 295, 22, g);
        g.setColor(Color.WHITE);
        g.drawString("Modificar contraseña", 85, 225);
        
        if( (usuarioActual instanceof Afiliado) || (usuarioActual instanceof  Supervisor) || (usuarioActual instanceof  Administrador)){
           
            boton(20, 250, 295, 22, g);
            g.setColor(Color.WHITE);
            g.drawString("Reservar Tiquetes", 85, 265);
            
        }
        if( (usuarioActual instanceof  Supervisor) || (usuarioActual instanceof  Administrador)){
            
            boton(20, 290, 295, 22, g);
            g.setColor(Color.WHITE);
            g.drawString("Registrar Películas", 85, 305);
            
            boton(20, 330, 295, 22, g);
            g.setColor(Color.WHITE);
            g.drawString("Crear una función", 85, 345);
            
            boton(20, 370, 295, 22, g);
            g.setColor(Color.WHITE);
            g.drawString("Crear usuario Afiliado", 75, 385);
            System.out.println(usuarioActual.nombre);
            
            boton(20, 450, 295, 22, g);
            g.setColor(Color.WHITE);
            g.drawString("Eliminar película", 85, 465);
            
            boton(20, 490, 295, 22, g);
            g.setColor(Color.WHITE);
            g.drawString("Eliminar función", 85, 505);
            
        }
        
        if( usuarioActual instanceof Administrador ){
            
            boton(20, 410, 295, 22, g);
            g.setColor(Color.WHITE);
            g.drawString("Crear usuario Supervisor", 75, 425);
            
            boton(20, 530, 295, 22, g);
            g.setColor(Color.WHITE);
            g.drawString("Eliminar usuario", 85, 545);
            
        }
        
        boton(20, 650, 295, 22, g);
        g.setColor(Color.WHITE);
        g.drawString("Estadísticas", 125, 675);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(fondo, 0, 0, this.getWidth(),this.getHeight(),null);
    }
    
    
    
    public void boton(int x, int y, int ancho, int alto, Graphics g){
        g.setColor(Color.BLACK);
        g.fillRect(x, y, ancho, alto);
    }
    
    public void textField(int x, int y, int ancho, int alto, Graphics g){
        g.setColor(Color.BLACK);
        g.drawRect(x, y, ancho, alto);
    }
    
    public void mostrarDialogo() {
        String ext[] = {"gif", "jpg", "jpeg", "png"};

        nomArchivo = "";
        JFileChooser fc = new JFileChooser(new File("."));

        FiltroArchivos filter = new FiltroArchivos(ext, "GIF, JPG, JPEG & PNG Imagenes");          	
        fc.setFileFilter(filter);

        int returnVal = fc.showOpenDialog(null);

        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();
            nomArchivo = file.getAbsolutePath();
            acepto = true;
        } else acepto = false;
    }
    
    public void copiarImg() {        
        try {
            nomArchivoCopiado = "nom_img " + getFecha() + "." + nomArchivo.substring(nomArchivo.indexOf('.') + 1, nomArchivo.length());
                        
            FileInputStream fis = new FileInputStream(nomArchivo); //UbicaciÃ³n del la imagen a copiar
            FileChannel inChannel = fis.getChannel();
                        
            FileOutputStream fos = new FileOutputStream("img_seleccionadas/" + nomArchivoCopiado); //UbicaciÃ³n donde se copiara la imagen                    
            FileChannel outChannel = fos.getChannel();
                        
            inChannel.transferTo(0, inChannel.size(), outChannel);
            fis.close();
            fos.close();
        } catch (IOException ioe) {
            JOptionPane.showMessageDialog(null, "Error al copiar la imagen" , 
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {   
        int x = e.getX();
        int y = e.getY();
        
        if( x >= 20 && x <= 315 && y >= 650 && y <= 672){
            ventana.setSize(1080, 768);
            ventana.pack();
            setVisible(false);
            ventana.estadisticas.repaint();
            ventana.estadisticas.setVisible(true);
            
        }
        
        // Consultar Películas y Comprar Tiquetes
        if( x >= 20 && x <= 315 && y >= 130 && y <= 152 ){
            ventana.setSize(1080, 768);
            ventana.pack();
            setVisible(false);
            ventana.consultaPeliculas.setVisible(true);
        }
        
        // Modificar Datos Personales
        if( x >= 20 && x <= 315 && y >= 160 && y <= 182 ){
            String opcion = Utilerias.leerCambioDatosPersonales();
            switch(opcion){
                case "Nombres":
                    usuarioActual.modificarNombres();
                    JOptionPane.showMessageDialog(null, "Datos modificados satisfactoriamente");
                    setUserName();
                    break;
                case "Apellidos":
                    usuarioActual.modificarApellidos();
                    JOptionPane.showMessageDialog(null, "Datos modificados satisfactoriamente");
                    break;
                case "Nombre de usuario":
                    usuarioActual.modificarUserName();
                    JOptionPane.showMessageDialog(null, "Datos modificados satisfactoriamente");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Por favor seleccione una opción");
            }
        }
        
        //Modificar Contraseña
        if( x >= 20 && x <= 315 && y >= 210 && y <= 232 ){
            System.out.println(usuarioActual.getNombre() + usuarioActual.getApellido() + usuarioActual.getUsuario());
            usuarioActual.modificarContrasena();
            JOptionPane.showMessageDialog(null, "Contraseña modificada satisfactoriamente");
        }
        
        //Reservar Tiquete
        if( x >= 20 && x <= 315 && y >= 240 && y <= 262 && ((usuarioActual instanceof Afiliado) || (usuarioActual instanceof  Supervisor) || (usuarioActual instanceof  Administrador))){
            setVisible(false);
            ventana.consultaPeliculas.setVisible(true);
        }
        
        //Registrar Películas
        if( x >= 20 && x <= 315 && y >= 270 && y <= 292 ){
            String nombrePelicula = Utilerias.leerString("Ingrese el nombre de la película:");
            String genero = Utilerias.leerString("Ingrese el genero de la película:");
            int duracion = Utilerias.leerInt("Ingrese la duración de la película(en minutos):");
            String clasificacion = Utilerias.leerString("¿Cual es la clasificación de la película?");
            String sinapsis = Utilerias.leerString("Sinapsis de la película:");
            String trailer = Utilerias.leerString("Ingrese el enlace al trailer de la película:");
            mostrarDialogo();
            ImageIcon  afiche = null;
            if(acepto){
                copiarImg();
                afiche = new ImageIcon("img_seleccionadas/" + nomArchivoCopiado);
            }
            Pelicula temp = new Pelicula(nombrePelicula, genero, duracion, clasificacion, sinapsis, trailer, afiche);
            ventana.principal.agregarPelicula(temp);
            ventana.consultaPeliculas.cargarAfiches();
            ventana.consultaPeliculas.repaint();
        }
        
        //Crear una función
        if( x >= 20 && x <= 315 && y >= 330 && y <= 352 ){
            String peliculaFuncion = Utilerias.seleccionDesplegable(ventana.principal.getNombresPeliculas(), "Seleccione la película a la cual desea agregar la función:");
            String hora = Utilerias.leerString("Ingrese la hora de la función (en formato 15:30)");
            String tipoFuncion = Utilerias.seleccionDesplegable(Utilerias.tiposFunciones, "¿Que tipo de función es?");
            ventana.principal.agregarFuncion(ventana.principal.setSala(tipoFuncion, hora, peliculaFuncion));
        }
        
        // Crear Usuario Afiliado
        if( x >= 20 && x <= 315 && y >= 370 && y <= 392 ){
            String nombres = Utilerias.leerString("Ingrese los nombres");
            String apellidos = Utilerias.leerString("Ingrese los apellidos");
            String usuario = Utilerias.leerString("Ingrese el nombre de usuario del usuario Afiliado");
            String contrasena = Utilerias.leerString("Ingrese la contraseña del usuatio Afiliado");
            usuarioActual.crearAfiliado(usuario, contrasena, nombres, apellidos);
            ventana.principal.getListaDeUsuarios().add(usuarioActual);
        }
        
        //Crear Usuario Supervisor
        if( x >= 20 && x <= 315 && y >= 410 && y <= 432 ){
           String nombres = Utilerias.leerString("Ingrese los nombres");
            String apellidos = Utilerias.leerString("Ingrese los apellidos");
            String usuario = Utilerias.leerString("Ingrese el nombre de usuario del usuario Afiliado");
            String contrasena = Utilerias.leerString("Ingrese la contraseña del usuatio Afiliado");
            usuarioActual.crearSupervisor(usuario, contrasena, nombres, apellidos);
            ventana.principal.getListaDeUsuarios().add(usuarioActual); 
        }
        
        //Eliminar Película
        if( x >= 20 && x <= 315 && y >= 450 && y <= 472 ){
            String nombreP = Utilerias.seleccionDesplegable(ventana.principal.getNombresPeliculas(), "Seleccione que película desea eliminar");
            for (int i = 0; i < ventana.principal.getListaDePeliculas().length; i++) {
                if(ventana.principal.getListaDePeliculas()[i].getNombre().equals(nombreP)){
                    ventana.principal.getListaDePeliculas()[i] = null;
                }
                
            }
        }
        
        //Eliminar Función
        if( x >= 20 && x <= 315 && y >= 490 && y <= 512 ){
            String[] listaFunciones = new String[ventana.principal.getListaFunciones().length];
            for (int i = 0; i < listaFunciones.length; i++) {
                listaFunciones[i] = ventana.principal.getListaFunciones()[i].toString();   
            }
            String sala = Utilerias.seleccionDesplegable(listaFunciones, "Seleccione la función que desea eliminar");
            for (int i = 0; i < ventana.principal.getListaFunciones().length; i++) {
                if(sala.equals(ventana.principal.getListaFunciones()[i].toString()))
                    ventana.principal.getListaFunciones()[i] = null;
                    break;
            }
            
        }
        
        //Eliminar Usuario
        if( x >= 20 && x <= 315 && y >= 530 && y <= 552 ){
            String userName = Utilerias.leerString("Ingrese el nombre del usuario el cual quiere eliminar:");
            for (int i = 0; i < ventana.principal.getListaDeUsuarios().size(); i++) {
                if(ventana.principal.getListaDeUsuarios().get(i).equals(userName)){
                    ventana.principal.getListaDeUsuarios().remove(i);
                }
                
            }
        }
            
    }

    public String seleccionarFuncion(){
        return Utilerias.seleccionDesplegable(ventana.comprarYReservar.getHoraFunciones(), "Seleccione la función:");
    }
    
    @Override
    public void mousePressed(MouseEvent e) {    }

    @Override
    public void mouseReleased(MouseEvent e) {    }

    @Override
    public void mouseEntered(MouseEvent e) {    }

    @Override
    public void mouseExited(MouseEvent e) {    }
    
}
