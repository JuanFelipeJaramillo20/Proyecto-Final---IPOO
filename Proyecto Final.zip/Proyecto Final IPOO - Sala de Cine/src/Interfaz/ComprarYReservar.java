/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package Interfaz;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import mundo.*;

/**
 *
 * @author juanf
 */
public class ComprarYReservar extends JPanel implements  MouseListener{

    private Ventana ventana;
    private Pelicula pelicula;
    private Funcion funcion;
    private Image fondo;
    private ArrayList<Funcion> funciones;
    private String[] horaFunciones;
    private String nombreFuncion;
    private int filaSilla;
    private int columnaSilla;
    private Random generadorReserva;
    
    public ComprarYReservar(Ventana Ventana) {
        this.ventana = Ventana;
        this.pelicula = null;
        this.funcion = null;
        fondo = new ImageIcon(getClass().getResource("/imagenes/comprarYReservar.png")).getImage();
        setSize(1080, 768);
        setLayout(null);
        addMouseListener(this);
        setLocation(0, 0);
        setVisible(false);
        funciones = new ArrayList<>();
        nombreFuncion = "";
        filaSilla = 0;
        columnaSilla = 0;
        generadorReserva = new Random();
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);        
    }

    public Ventana getVentana() {
        return ventana;
    }

    public void setVentana(Ventana ventana) {
        this.ventana = ventana;
    }

    public Image getFondo() {
        return fondo;
    }

    public void setFondo(Image fondo) {
        this.fondo = fondo;
    }

    public ArrayList<Funcion> getFunciones() {
        return funciones;
    }

    public void setFunciones(ArrayList<Funcion> funciones) {
        this.funciones = funciones;
    }

    public String[] getHoraFunciones() {
        return horaFunciones;
    }

    public void setHoraFunciones(String[] horaFunciones) {
        this.horaFunciones = horaFunciones;
    }

    
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(fondo, 0, 0, this.getWidth(), 730, null);
        g.drawImage(pelicula.getAfiche().getImage(), 900, 10, 146, 207, null);
        Font f = new Font("Lucida Calligraphy", Font.ITALIC, 36);
        g.setFont(f);
        g.setColor(Color.WHITE);
        g.drawString(Double.toString(calcularValorBoleta()), 215, 141);
        g.drawString(funcion.getTipoFuncion(), 185, 87);
        int y = 350;
        for (char[] linea : funcion.getSala().getSillas()) {
            g.drawString(Arrays.toString(linea), 265, y);
            y += 40;
        }
    }
    
    public double calcularValorBoleta(){
        double valorBoleta = 0;
        if (ventana.menuUsuario.getUsuarioActual() instanceof Afiliado) {
                valorBoleta = aplicarDescuento(funcion.getSala().getValorTiquete());
            }else{
                valorBoleta = funcion.getSala().getValorTiquete();
            }
        return valorBoleta;
    }
    
    public void comprar(int fila, int columna){
        funcion.getSala().getSillas()[fila][columna] = 'X';
        Tiquete tiquete = new Tiquete(funcion, fila, columna);
        tiquete.generarTiquete();
    }
    
    public void refrescarSillas(int fila, int columna){
        funcion.getSala().getSillas()[fila][columna] = 'X';
    }
    
    public void reservar(int fila, int columna){
        funcion.getSala().getSillas()[fila][columna] = 'X';
        repaint();
        boolean antorcha = false;
        int codigoReserva = 0;
        funcion.getSala().getSillas()[fila][columna] = 'X';
        Tiquete tiquete = new Tiquete(funcion, fila, columna);
        do {            
            codigoReserva = generadorReserva.nextInt(100);
            antorcha = buscarReserva(codigoReserva);
        } while (antorcha);
        Reserva reserva = new Reserva(funcion, fila, columna, codigoReserva);
        ventana.principal.getListaReservas().add(reserva);
        JOptionPane.showMessageDialog(null, "Su reserva se ha realizado correctamente, pase a la sede del cine con su código para reclamar su boleta.");
    }
    
    public boolean buscarReserva(int numeroReserva){
        boolean encontrado = false;
        for (int i = 0; i < ventana.principal.getListaReservas().size(); i++) {
            if(ventana.principal.getListaReservas().get(i).getCodigoReserva() == numeroReserva){
                encontrado = true;
            }
        }
        return encontrado;
    }
    
    public double aplicarDescuento(double precio){
        return precio * 0.9;
    }
    
    public void llenarListaFunciones(){
        for (int i = 0; i < ventana.principal.getListaFunciones().length; i++) {
            if(ventana.principal.getListaFunciones()[i] != null){
                if(ventana.principal.getListaFunciones()[i].getPelicula().getNombre().equals(pelicula.getNombre())){
               funciones.add(ventana.principal.getListaFunciones()[i]);
            }
            }
        }
    }
    
    public String seleccionarFuncion(){
        return Utilerias.seleccionDesplegable(ventana.comprarYReservar.getHoraFunciones(), "Seleccione la función:");
    }
    
    public void listaFuncionesPorHora(){
        horaFunciones = new String[funciones.size()];
        for (int i = 0; i < horaFunciones.length; i++) {
            horaFunciones[i] = funciones.get(i).getHora() + " - " + funciones.get(i).getTipoFuncion() + " - Sala: " + funciones.get(i).getSala().getNombreSala();
        }
    }
    
    public void setPelicula(Pelicula pelicula){
        this.pelicula = pelicula;
    }
            
    public void setFuncion(){
        for (int i = 0; i < ventana.principal.getListaFunciones().length; i++) {
            if(ventana.principal.getListaFunciones()[i] != null){
                String comparar = ventana.principal.getListaFunciones()[i].getHora() + " - " + ventana.principal.getListaFunciones()[i].getTipoFuncion() + " - Sala: " + ventana.principal.getListaFunciones()[i].getSala().getNombreSala();
                if(nombreFuncion.equals(comparar)){
                    funcion = ventana.principal.getListaFunciones()[i];
                }
            }
        }
    }
    
    public Funcion buscarFuncion(){
        Funcion temp = null;
        for (int i = 0; i < ventana.principal.getListaFunciones().length; i++) {
            if(ventana.principal.getListaFunciones()[i] != null){
                String comparar = ventana.principal.getListaFunciones()[i].getHora() + " - " + ventana.principal.getListaFunciones()[i].getTipoFuncion() + " - Sala: " + ventana.principal.getListaFunciones()[i].getSala().getNombreSala();
                if(nombreFuncion.equals(comparar)){
                    temp = ventana.principal.getListaFunciones()[i];
                }
            }
        }
        return temp;
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        
        if( x >= 266 && x <= 316 && y >= 317 && y <= 357)
        {
         filaSilla = 0;
         columnaSilla = 0;
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 318 && x <= 368 && y >= 317 && y <= 357)
        {filaSilla = 0;
         columnaSilla = 1; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 370 && x <= 420 && y >= 317 && y <= 357)
        {filaSilla = 0;
         columnaSilla = 2; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 422 && x <= 472 && y >= 317 && y <= 357)
        {filaSilla = 0;
         columnaSilla = 3; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 474 && x <= 524 && y >= 317 && y <= 357)
        {filaSilla = 0;
         columnaSilla = 4; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 526 && x <= 576 && y >= 317 && y <= 357)
        {filaSilla = 0;
         columnaSilla = 5; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 578 && x <= 628 && y >= 317 && y <= 357)
        {filaSilla = 0;
         columnaSilla = 6; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 630 && x <= 680 && y >= 317 && y <= 357)
        {filaSilla = 0;
         columnaSilla = 7; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 682 && x <= 732 && y >= 317 && y <= 357)
        {filaSilla = 0;
         columnaSilla = 8; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 734 && x <= 784 && y >= 317 && y <= 357)
        {filaSilla = 0;
         columnaSilla = 9; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 786 && x <= 836 && y >= 317 && y <= 357)
        {filaSilla = 0;
         columnaSilla = 10; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        
        //Segunda Fila
        if( x >= 266 && x <= 316 && y >= 360 && y <= 400)
        {filaSilla = 1;
         columnaSilla = 0; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 318 && x <= 368 && y >= 360 && y <= 400)
        {filaSilla = 1;
         columnaSilla = 1; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 370 && x <= 420 && y >= 360 && y <= 400)
        {filaSilla = 1;
         columnaSilla = 2; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 422 && x <= 472 && y >= 360 && y <= 400)
        {filaSilla = 1;
         columnaSilla = 3; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 474 && x <= 524 && y >= 360 && y <= 400)
        {filaSilla = 1;
         columnaSilla = 4; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 526 && x <= 576 && y >= 360 && y <= 400)
        {filaSilla = 1;
         columnaSilla = 5; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 578 && x <= 628 && y >= 360 && y <= 400)
        {filaSilla = 1;
         columnaSilla = 6; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 630 && x <= 680 && y >= 360 && y <= 400)
        {filaSilla = 1;
         columnaSilla = 7; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 682 && x <= 732 && y >= 360 && y <= 400)
        {filaSilla = 1;
         columnaSilla = 8; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 734 && x <= 784 && y >= 360 && y <= 400)
        {filaSilla = 1;
         columnaSilla = 9; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 786 && x <= 836 && y >= 360 && y <= 400)
        {filaSilla = 1;
         columnaSilla = 10; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        
        //Tercer Fila
        if( x >= 266 && x <= 316 && y >= 403 && y <= 443)
        {filaSilla = 2;
         columnaSilla = 0; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 318 && x <= 368 && y >= 403 && y <= 443)
        {filaSilla = 2;
         columnaSilla = 1; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 370 && x <= 420 && y >= 403 && y <= 443)
        {filaSilla = 2;
         columnaSilla = 2; 
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 422 && x <= 472 && y >= 403 && y <= 443)
        {filaSilla = 2;
         columnaSilla = 3;
         refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 474 && x <= 524 && y >= 403 && y <= 443)
        {filaSilla = 2;
         columnaSilla = 4; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 526 && x <= 576 && y >= 403 && y <= 443)
        {filaSilla = 2;
         columnaSilla = 5; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 578 && x <= 628 && y >= 403 && y <= 443)
        {filaSilla = 2;
         columnaSilla = 6; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 630 && x <= 680 && y >= 403 && y <= 443)
        {filaSilla = 2;
         columnaSilla = 7; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 682 && x <= 732 && y >= 403 && y <= 443)
        {filaSilla = 2;
         columnaSilla = 8; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 734 && x <= 784 && y >= 403 && y <= 443)
        {filaSilla = 2;
         columnaSilla = 9; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 786 && x <= 836 && y >= 403 && y <= 443)
        {filaSilla = 2;
         columnaSilla = 10; 
          refrescarSillas(filaSilla, columnaSilla);
        }

        //Cuarta Fila
        if( x >= 266 && x <= 316 && y >= 446 && y <= 486)
        {filaSilla = 3;
         columnaSilla = 0; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 318 && x <= 368 && y >= 446 && y <= 486)
        {filaSilla = 3;
         columnaSilla = 1; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 370 && x <= 420 && y >= 446 && y <= 486)
        {filaSilla = 3;
         columnaSilla = 2; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 422 && x <= 472 && y >= 446 && y <= 486)
        {filaSilla = 3;
         columnaSilla = 3; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 474 && x <= 524 && y >= 446 && y <= 486)
        {filaSilla = 3;
         columnaSilla = 4; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 526 && x <= 576 && y >= 446 && y <= 486)
        {filaSilla = 3;
         columnaSilla = 5; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 578 && x <= 628 && y >= 446 && y <= 486)
        {filaSilla = 3;
         columnaSilla = 6; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 630 && x <= 680 && y >= 446 && y <= 486)
        {filaSilla = 3;
         columnaSilla = 7; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 682 && x <= 732 && y >= 446 && y <= 486)
        {filaSilla = 3;
         columnaSilla = 8; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 734 && x <= 784 && y >= 446 && y <= 486)
        {filaSilla = 3;
         columnaSilla = 9; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 786 && x <= 836 && y >= 446 && y <= 486)
        {filaSilla = 3;
         columnaSilla = 10; 
          refrescarSillas(filaSilla, columnaSilla);
        }

        //Quinta Fila
        if( x >= 266 && x <= 316 && y >= 489 && y <= 529)
        {filaSilla = 4;
         columnaSilla = 0; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 318 && x <= 368 && y >= 489 && y <= 529)
        {filaSilla = 4;
         columnaSilla = 1; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 370 && x <= 420 && y >= 489 && y <= 529)
        {filaSilla = 4;
         columnaSilla = 2; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 422 && x <= 472 && y >= 489 && y <= 529)
        {filaSilla = 4;
         columnaSilla = 3; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 474 && x <= 524 && y >= 489 && y <= 529)
        {filaSilla = 4;
         columnaSilla = 4; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 526 && x <= 576 && y >= 489 && y <= 529)
        {filaSilla = 4;
         columnaSilla = 5; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 578 && x <= 628 && y >= 489 && y <= 529)
        {filaSilla = 4;
         columnaSilla = 6; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 630 && x <= 680 && y >= 489 && y <= 529)
        {filaSilla = 4;
         columnaSilla = 7; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 682 && x <= 732 && y >= 489 && y <= 529)
        {filaSilla = 4;
         columnaSilla = 8; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 734 && x <= 784 && y >= 489 && y <= 529)
        {filaSilla = 4;
         columnaSilla = 9; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 786 && x <= 836 && y >= 489 && y <= 529)
        {filaSilla = 4;
         columnaSilla = 10; 
          refrescarSillas(filaSilla, columnaSilla);
        }

        //Sexta Fila
        if( x >= 266 && x <= 316 && y >= 532 && y <= 572)
        {filaSilla = 5;
         columnaSilla = 0; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 318 && x <= 368 && y >= 532 && y <= 572)
        {filaSilla = 5;
         columnaSilla = 1; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 370 && x <= 420 && y >= 532 && y <= 572)
        {filaSilla = 5;
         columnaSilla = 2; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 422 && x <= 472 && y >= 532 && y <= 572)
        {filaSilla = 5;
         columnaSilla = 3; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 474 && x <= 524 && y >= 532 && y <= 572)
        {filaSilla = 5;
         columnaSilla = 4; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 526 && x <= 576 && y >= 532 && y <= 572)
        {filaSilla = 5;
         columnaSilla = 5; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 578 && x <= 628 && y >= 532 && y <= 572)
        {filaSilla = 5;
         columnaSilla = 6; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 630 && x <= 680 && y >= 532 && y <= 572)
        {filaSilla = 5;
         columnaSilla = 7; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 682 && x <= 732 && y >= 532 && y <= 572)
        {filaSilla = 5;
         columnaSilla = 8; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 734 && x <= 784 && y >= 532 && y <= 572)
        {filaSilla = 5;
         columnaSilla = 9; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 786 && x <= 836 && y >= 532 && y <= 572)
        {filaSilla = 5;
         columnaSilla = 10; 
          refrescarSillas(filaSilla, columnaSilla);
        }

        //Séptima Fila
        if( x >= 266 && x <= 316 && y >= 575 && y <= 615)
        {filaSilla = 6;
         columnaSilla = 0; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 318 && x <= 368 && y >= 575 && y <= 615)
        {filaSilla = 6;
         columnaSilla = 1; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 370 && x <= 420 && y >= 575 && y <= 615)
        {filaSilla = 6;
         columnaSilla = 2; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 422 && x <= 472 && y >= 575 && y <= 615)
        {filaSilla = 6;
         columnaSilla = 3; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 474 && x <= 524 && y >= 575 && y <= 615)
        {filaSilla = 6;
         columnaSilla = 4; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 526 && x <= 576 && y >= 575 && y <= 615)
        {filaSilla = 6;
         columnaSilla = 5; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 578 && x <= 628 && y >= 575 && y <= 615)
        {filaSilla = 6;
         columnaSilla = 6; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 630 && x <= 680 && y >= 575 && y <= 615)
        {filaSilla = 6;
         columnaSilla = 7; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 682 && x <= 732 && y >= 575 && y <= 615)
        {filaSilla = 6;
         columnaSilla = 8; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 734 && x <= 784 && y >= 575 && y <= 615)
        {filaSilla = 6;
         columnaSilla = 9; 
          refrescarSillas(filaSilla, columnaSilla);
        }
        if( x >= 786 && x <= 836 && y >= 575 && y <= 615)
        {filaSilla = 6;
         columnaSilla = 10; 
          refrescarSillas(filaSilla, columnaSilla);
        }

        if( x >= 568 && x <= 801 && y >= 682 && y <= 713 ){
            reservar(filaSilla, columnaSilla);
        }

        if( x >= 830 && x <= 1062 && y >= 682 && y <= 713 ){
            comprar(filaSilla, columnaSilla);
        }

    }

    @Override
    public void mousePressed(MouseEvent e) {    }

    @Override
    public void mouseReleased(MouseEvent e) {    }

    @Override
    public void mouseEntered(MouseEvent e) {    }

    @Override
    public void mouseExited(MouseEvent e) {    }

    void setNombreFuncion(String nombreFuncion) {
        this.nombreFuncion = nombreFuncion;
    }
    
}
