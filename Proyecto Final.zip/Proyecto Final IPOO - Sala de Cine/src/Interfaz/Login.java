/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package Interfaz;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.File;
import java.util.Locale;
import java.util.Objects;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import mundo.ProyectoFinalIPOOSalaDeCine;
import mundo.Usuario;


public class Login extends JPanel implements MouseListener{

    
    private Image fondo;
    private String usuario = "";
    private String password = "";
    Usuario temp = null;
    Ventana ventana;

    public Login(Ventana ventana) {
        
        this.ventana = ventana;
        fondo = new ImageIcon(getClass().getResource("/imagenes/Login.png")).getImage();
        setSize(350,756);
        setLocation(0,0);
        setLayout(null);
        addMouseListener(this);
        setVisible(false);
    }
    
    public void paint(Graphics g){
        super.paint(g);
        Font f = new Font("Lucida Calligraphy", Font.ITALIC, 18);
        g.setFont(f);
        rellenarUsuario(g);
        rellenarPassword(g);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); 
        g.drawImage(fondo, 0, 0,this.getWidth(),this.getHeight(), null);
    }
    
    public void rellenarUsuario( Graphics g){
        Font f = new Font("Lucida Calligraphy", Font.ITALIC, 12);
        g.setColor(Color.BLACK);
        g.setFont(f);
        g.drawString(usuario, 125, 350);
    }
    
    public void rellenarPassword( Graphics g){
        Font f = new Font("Lucida Calligraphy", Font.ITALIC, 12);
        g.setFont(f);
        String contrasena = "";
        for(int i = 0 ; i < password.length() ; i++){
            contrasena += "*";
        }
        g.drawString(contrasena, 125, 410);
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        //Texto Nombre de Usuario
        if ( x >= 87 && x <= 264 && y >=334 && y <= 356 ) {
            usuario = JOptionPane.showInputDialog("Ingrese su nombre de usuario");
            repaint();
        }
        //Texto Contraseña
        if ( x >= 87 && x <= 264 && y >=396 && y <= 425 ) {
            password = JOptionPane.showInputDialog("Ingrese su contraseña:");
            repaint();
        }
        //Boton Iniciar Sesión
        if ( x >= 120 && x <= 230 && y >=454 && y <= 470 ) {
            if(!usuario.equals(null) && !password.equals(null)){
                temp = ventana.principal.ingresar(usuario, password);
            }
            if(Objects.isNull(temp)){
                JOptionPane.showMessageDialog(null, "No se pudo iniciar sesión. Por favor intente de nuevo");
            }else{
                setVisible(false);
                ventana.menuUsuario.setUsuario(temp);
                ventana.menuUsuario.setUserName();
                ventana.menuUsuario.setVisible(true);
            }
            
        }
        //Boton Registrarse
        if ( x >= 671 && x <= 1021 && y >=1468 && y <= 1538 ) {
            
        }
    }

    public void mousePressed(MouseEvent e) { }
    public void mouseReleased(MouseEvent e) { }
    public void mouseEntered(MouseEvent e) { }
    public void mouseExited(MouseEvent e) { }
    
    
}
