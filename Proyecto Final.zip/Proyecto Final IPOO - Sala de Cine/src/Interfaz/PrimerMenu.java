/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package Interfaz;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 *
 * @author juanf
 */
public class PrimerMenu extends JPanel implements MouseListener{
    
     private Image fondo;
     Ventana ventana;

    public PrimerMenu(Ventana ventana) {
        this.ventana = ventana;
        fondo = new ImageIcon(getClass().getResource("/imagenes/PrimerMenu.png")).getImage();
        setSize(350,756);
        setLocation(0,0);
        setLayout(null);
        addMouseListener(this);
        setVisible(true);
    }
    
    public void boton(int x, int y, int ancho, int alto, Graphics g){
        g.setColor(Color.BLACK);
        //g.fillRect(x, y, WIDTH, HEIGHT)
    }
    
    public void textField(int x, int y, int ancho, int alto, Graphics g){
        g.setColor(Color.BLACK);
        g.drawRect(x, y, ancho, alto);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font f = new Font("Lucida Calligraphy", Font.ITALIC, 18);
        
        boton(90, 375, 150, 30, g);
        
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(fondo, 0, 0,this.getWidth(),this.getHeight(), null);
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        
        if ( x >= 57 && x <= 290 && y >= 226 && y <= 275 ){
            setVisible(false);
            ventana.login.setVisible(true);
        }
        if ( x >= 57 && x <= 290 && y >= 314 && y <= 363 ){
            setVisible(false);
            ventana.registro.setVisible(true);
        }
        if ( x >= 57 && x <= 290 && y >= 416 && y <= 465 ){
            setVisible(false);
            ventana.setSize(1080,768);
            ventana.pack();
            ventana.consultaPeliculas.setVisible(true);
        }
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }
    
    
    
}
