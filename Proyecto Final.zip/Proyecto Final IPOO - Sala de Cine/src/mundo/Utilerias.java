/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package mundo;

import javax.swing.JOptionPane;

/**
 *
 * @author juanf
 */
public class Utilerias {
    
    public static String[] datosPersonales = {"Nombres",
        "Apellidos",
        "Nombre de usuario"};
    
    public static String[] tiposFunciones = {"2D", "3D", "VIP"};
    
    public static double leerDouble(String etiqueta){
        String ent = JOptionPane.showInputDialog(etiqueta);
        double real = Double.parseDouble(ent);
        return real;
    }
    
    public static String seleccionDesplegable(String[] listaOpciones, String etiqueta){
        String seleccion = (String) JOptionPane.showInputDialog(null,etiqueta,"Selección",JOptionPane.QUESTION_MESSAGE, null,listaOpciones, listaOpciones[0]);
        return seleccion;
    }
    
    public static int leerInt(String etiqueta){
        String ent = JOptionPane.showInputDialog(etiqueta);
        int entero = Integer.parseInt(ent);
        return entero;
    }
    
    public static char leerChar(String etiqueta){
        String ent = JOptionPane.showInputDialog(etiqueta);
        char caracter = ent.charAt(0);
        return caracter;
    }
    
    public static String leerCambioDatosPersonales(){
        String plan = (String) JOptionPane.showInputDialog(null,"Selecciona el dato que quieras cambiar","Datos personales",JOptionPane.QUESTION_MESSAGE, null,datosPersonales, datosPersonales[0]);
        return plan;
    }
    
    public static String leerString(String etiqueta){
        String texto = (String) JOptionPane.showInputDialog(etiqueta);
        return texto;
    }
}
