/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package mundo;


public class SalaVIP extends Sala{

    public SalaVIP(String nombreSala) {
        super(nombreSala);
        valorTiquete = 18000;
        sillas = new char[8][4];
        inicializarSillas();
    }

    @Override
    public void inicializarSillas() {
        super.inicializarSillas();
        sillas[7][2] = 'X';
        sillas[7][3] = 'X';
    }
    
    
    
}
