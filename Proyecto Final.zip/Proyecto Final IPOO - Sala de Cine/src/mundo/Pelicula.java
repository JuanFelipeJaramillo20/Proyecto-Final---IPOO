/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package mundo;

import java.awt.Image;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.ImageIcon;

/**
 *
 * @author juanf
 */
public class Pelicula {
    
    public String nombre;
    public String genero;
    public int duracion;
    public String clasificacion;
    public String sinapsis;
    public String trailer;
    public ImageIcon afiche;
    private ArrayList<String> opiniones;

    public Pelicula(String nombre, String genero, int duracion,String clasificacion , String sinapsis, String trailer, ImageIcon afiche) {
        this.nombre = nombre;
        this.genero = genero;
        this.duracion = duracion;
        this.clasificacion = clasificacion;
        this.sinapsis = sinapsis;
        this.trailer = trailer;
        this.afiche = afiche;
        opiniones = new ArrayList<>();
    }

    public void agregarOpinion(String opinion){
        opiniones.add(opinion);
    }
    
    public String getNombre() {
        return nombre;
    }

    public String getClasificacion() {
        return clasificacion;
    }

    public void setClasificacion(String clasificacion) {
        this.clasificacion = clasificacion;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public ImageIcon getAfiche() {
        return afiche;
    }

    public void setAfiche(ImageIcon afiche) {
        this.afiche = afiche;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public ArrayList<String> getOpiniones() {
        return opiniones;
    }

    public void setOpiniones(ArrayList<String> opiniones) {
        this.opiniones = opiniones;
    }
    

    public String getSinapsis() {
        return sinapsis;
    }

    public void setSinapsis(String sinapsis) {
        this.sinapsis = sinapsis;
    }

    public String getTrailer() {
        return trailer;
    }

    public void setTrailer(String trailer) {
        this.trailer = trailer;
    }
    
    public String  mostrarInfoPelicula(){
        String info = nombre + "\n"
                + genero + "\n"
                + duracion + "\n"
                + clasificacion + "\n"
                +sinapsis + "\n"
                + "Trailer: " + trailer + "\n";
        return info;
    }
    
}
