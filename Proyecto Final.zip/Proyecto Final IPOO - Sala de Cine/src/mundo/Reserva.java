/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package mundo;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.JOptionPane;


public class Reserva {
    
    public Funcion funcionTiquete;
    public int fila;
    public int columna;
    public int codigoReserva;

    public Reserva(Funcion funcionTiquete, int fila, int columna, int codigoReserva) {
        this.funcionTiquete = funcionTiquete;
        this.fila = fila;
        this.columna = columna;
        this.codigoReserva = codigoReserva;
    }
    
    public Funcion getFuncionTiquete() {
        return funcionTiquete;
    }

    public void setFuncionTiquete(Funcion funcionTiquete) {
        this.funcionTiquete = funcionTiquete;
    }

    public int getFila() {
        return fila;
    }

    public void setFila(int fila) {
        this.fila = fila;
    }

    public int getColumna() {
        return columna;
    }

    public void setColumna(int columna) {
        this.columna = columna;
    }

    public int getCodigoReserva() {
        return codigoReserva;
    }

    public void setCodigoReserva(int codigoReserva) {
        this.codigoReserva = codigoReserva;
    }
    
    public void generarReserva(Usuario user ){
        Document tiquete = new Document();
        try {
            funcionTiquete.getSala().marcarSilla(fila, columna);
            PdfWriter writer = PdfWriter.getInstance(tiquete, new FileOutputStream("Reserva.pdf"));
            tiquete.open();
            
            PdfContentByte cb = writer.getDirectContent();
            Graphics g = cb.createGraphicsShapes(PageSize.A6.getWidth(), PageSize.A5.getHeight());
            Font font = new Font("Arial", Font.BOLD + Font.ITALIC, 18);
            g.setFont(font);
            g.setColor(Color.yellow);
            
            g.drawString("Información de su reserva:", 874, 100);
            g.drawString("Película: " + funcionTiquete.getPelicula().getNombre(), 100, 300);
            g.drawString("Su código de reserva es: " + codigoReserva, 100, 450);
            g.drawString("Nombre de la persona de la reserva: " + user.getNombre() + " " + user.getApellido(), 100, 600);
            g.drawString("Ingrese su código de reserva en el apartado 'Tengo una reserva' para la impresión de su tiquete", 100, 750);
            
        } catch (DocumentException de) {
            System.err.println(de.getMessage());
        } catch (IOException ioe) {
            System.err.println(ioe.getMessage());
        }
    }
    
    public void canjearReserva(int codigoReserva, Reserva[] listaReservas){
        for (int i = 0; i < listaReservas.length; i++) {
            if(codigoReserva == listaReservas[i].getCodigoReserva()){
                Tiquete boleta = new Tiquete(listaReservas[i].getFuncionTiquete(), listaReservas[i].getFila(), listaReservas[i].getColumna());
                break;
            }else{
                JOptionPane.showMessageDialog(null, "No hay una reserva con ese código. Por favor intentelo de nuevo");
            }
            
        }
    }

    @Override
    public String toString() {
        return "Reserva{" + "funcionTiquete=" + funcionTiquete + ", fila=" + fila + ", columna=" + columna + ", codigoReserva=" + codigoReserva + '}';
    }
    
    
    
}
