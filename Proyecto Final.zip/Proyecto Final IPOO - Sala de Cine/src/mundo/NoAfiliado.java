/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package mundo;

/**
 *
 * @author juanf
 */
public class NoAfiliado extends Usuario {

    public NoAfiliado(String usuario, String password, String nombre, String apellido) {
        super(usuario, password, nombre, apellido);
    }
    
}
