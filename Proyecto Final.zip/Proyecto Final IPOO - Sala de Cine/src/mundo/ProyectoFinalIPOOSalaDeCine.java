/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package mundo;

import Interfaz.Login;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class ProyectoFinalIPOOSalaDeCine extends JPanel implements MouseListener {
    
    private ArrayList<Usuario> listaDeUsuarios;
    private Pelicula[] listaDePeliculas;
    private Sala[] listaDeSalas;
    private String[] nombresPeliculas;
    private Funcion[] listaFunciones;
    private Sala2D[] salas2D;
    private Sala3D[] salas3D;
    private Login login;
    private Image fondo;
    private ArrayList<Reserva> listaReservas;
    Sala2D sala1;
    Sala2D sala2;
    Sala2D sala3;
    Sala3D sala4;
    Sala3D sala5;
    SalaVIP sala6;
    Pelicula prueba;

    public ProyectoFinalIPOOSalaDeCine() {
        inicializar();
    }

    public ArrayList<Reserva> getListaReservas() {
        return listaReservas;
    }

    public void setListaReservas(ArrayList<Reserva> listaReservas) {
        this.listaReservas = listaReservas;
    }

    public void inicializar(){
        sala1 = new Sala2D("2D1");
        sala2 = new Sala2D("2D2");
        sala3 = new Sala2D("2D3");
        sala4 = new Sala3D("3D1");
        sala5 = new Sala3D("3D2");
        sala6 = new SalaVIP("VIP1");
        listaDeSalas = new Sala[6];
        listaDeSalas[0] = sala1;
        listaDeSalas[1] = sala2;
        listaDeSalas[2] = sala3;
        listaDeSalas[3] = sala4;
        listaDeSalas[4] = sala5;
        listaDeSalas[5] = sala6;
        
        ImageIcon afiche = new ImageIcon(getClass().getResource("/imagenes/godzilla-vs-king-kong_qw9s.jpg"));
        prueba = new Pelicula("Godzilla", "Genero", 220, "+18", "peleas", "trailer", afiche);
        
        
        salas2D = new Sala2D[3];
        salas2D[0] = sala1;
        salas2D[1] = sala2;
        salas2D[2] = sala3;
        
        
        salas3D = new Sala3D[2];
        salas3D[0] = sala4;
        salas3D[1] = sala5;
        
        
        listaReservas = new ArrayList<>();
        
        Administrador jefe = new Administrador("Admin", "Admin", "Juan Felipe", "Jaramillo");
        listaDeUsuarios = new ArrayList<>();
        listaDeUsuarios.add(jefe);
        
        listaDePeliculas = new Pelicula[4];
        listaDePeliculas[0] = prueba;
        rellenarNombresPeliculas();
        
        listaFunciones = new Funcion[6];
    }
    
    public void agregarFuncion(Funcion funcion){
        for (int i = 0; i < listaFunciones.length; i++) {
            if(listaFunciones[i] == null){
                listaFunciones[i] = funcion;
                break;
            }
            
        }
    }
    
    public void agregarPelicula(Pelicula pelicula){
        for (int i = 0; i < listaDePeliculas.length; i++) {
            if(listaDePeliculas[i] == null){
                listaDePeliculas[i] = pelicula;
                break;
            }   
        }
    }
    
    public Pelicula setPelicula(String pelicula){
        Pelicula temp = null;
        for (int i = 0; i < listaDePeliculas.length; i++) {
            if (listaDePeliculas[i] != null) {
                if(pelicula.equals(listaDePeliculas[i].getNombre())){
                temp = listaDePeliculas[i];
                break;
            }
            }
        }
        return temp;
    }
    
    public Funcion setSala(String tipoFuncion, String hora, String pelicula){
        Funcion temp = new Funcion(null, null, null);
        if (tipoFuncion.equals("2D")) {
            for (int i = 0; i < salas2D.length; i++) {
                if(salas2D[i].isOcupada() == false){
                    salas2D[i].setOcupada(true);
                    temp.setHora(hora);
                    temp.setPelicula(setPelicula(pelicula));
                    temp.setSala(salas2D[i]);
                    temp.setTipoFuncion(tipoFuncion);
                }
                
            }
        }
        if (tipoFuncion.equals("3D")) {
            for (int i = 0; i < salas3D.length; i++) {
                if (salas3D[i].isOcupada() == false) {
                    salas3D[i].setOcupada(true);
                    temp.setHora(hora);
                    temp.setPelicula(setPelicula(pelicula));
                    temp.setSala(salas3D[i]);
                    temp.setTipoFuncion(tipoFuncion);
                }
                
            }
        }
        if (tipoFuncion.equals("VIP")) {
            if (!sala6.isOcupada()) {
                sala6.setOcupada(true);
                temp.setHora(hora);
                temp.setPelicula(setPelicula(pelicula));
                temp.setSala(sala6);
                temp.setTipoFuncion(tipoFuncion);
            }
        }
        return temp;
    }

    public Sala2D[] getSalas2D() {
        return salas2D;
    }

    public void setSalas2D(Sala2D[] salas2D) {
        this.salas2D = salas2D;
    }

    public Sala3D[] getSalas3D() {
        return salas3D;
    }

    public void setSalas3D(Sala3D[] salas3D) {
        this.salas3D = salas3D;
    }

    public Sala2D getSala1() {
        return sala1;
    }

    public void setSala1(Sala2D sala1) {
        this.sala1 = sala1;
    }

    public Sala2D getSala2() {
        return sala2;
    }

    public void setSala2(Sala2D sala2) {
        this.sala2 = sala2;
    }

    public Sala2D getSala3() {
        return sala3;
    }

    public void setSala3(Sala2D sala3) {
        this.sala3 = sala3;
    }

    public Sala3D getSala4() {
        return sala4;
    }

    public void setSala4(Sala3D sala4) {
        this.sala4 = sala4;
    }

    public Sala3D getSala5() {
        return sala5;
    }

    public void setSala5(Sala3D sala5) {
        this.sala5 = sala5;
    }

    public SalaVIP getSala6() {
        return sala6;
    }

    public void setSala6(SalaVIP sala6) {
        this.sala6 = sala6;
    }
    
    public void rellenarNombresPeliculas(){
        nombresPeliculas = new String[listaDePeliculas.length];
        for (int i = 0; i < listaDePeliculas.length; i++) {
            if(listaDePeliculas[i] != null){
                nombresPeliculas[i] = listaDePeliculas[i].getNombre();
            }
        }
    }
    
    
    
    public Usuario ingresar(String usuario, String password){
        Supervisor tempSupervisor = null;
        Afiliado tempAfiliado = null;
        NoAfiliado tempNoAfiliado = null;
        Administrador tempAdministrador = null;
        for (int i = 0; i < listaDeUsuarios.size(); i++) {
            if(listaDeUsuarios.get(i).getUsuario().equals(usuario) && listaDeUsuarios.get(i).getPassword().equals(password)){
                JOptionPane.showMessageDialog(null, "Ha ingresado correctamente a la aplicación. Bienvenido!");
                if(listaDeUsuarios.get(i) instanceof Supervisor){
                    tempSupervisor = (Supervisor) listaDeUsuarios.get(i);
                    return tempSupervisor;
                }else if(listaDeUsuarios.get(i) instanceof Afiliado){
                    tempAfiliado = (Afiliado) listaDeUsuarios.get(i);
                    return tempAfiliado;
                }else if(listaDeUsuarios.get(i) instanceof NoAfiliado){
                    tempNoAfiliado = (NoAfiliado) listaDeUsuarios.get(i);
                    return tempNoAfiliado;
                }else if(listaDeUsuarios.get(i) instanceof Administrador){
                    tempAdministrador = (Administrador) listaDeUsuarios.get(i);
                    return tempAdministrador;
                }else{
                   return null;
                } 
            }
        }
        return null;
    }
    
    public int boletasVendidas(){
        int vendidas = 0;
        for (int i = 0; i < listaDeSalas.length; i++) {
            for(int j = 0 ; j < listaDeSalas[i].getSillas().length ; j++){
                for(int k = 0 ; k < listaDeSalas[i].getSillas()[j].length ; k++){
                    if(listaDeSalas[i].getSillas()[j][k] == 'X'){
                        vendidas++;
                    }
                }
            }
            
        }
        return vendidas;
    }
    
    public int boletasDisponibles(){
        int disponibles = 0;
        for (int i = 0; i < listaDeSalas.length; i++) {
            for(int j = 0 ; j < listaDeSalas[i].getSillas().length ; j++){
                for(int k = 0 ; k < listaDeSalas[i].getSillas()[j].length ; k++){
                    if(listaDeSalas[i].getSillas()[j][k] == 'O'){
                        disponibles++;
                    }
                }
            }
            
        }
        return disponibles;
    }
    
    public void crearUsuarioNoAfiliado(String usuario, String nombres, String apellidos, String contrasena){
       NoAfiliado noAfiliado = new NoAfiliado(usuario, contrasena, nombres, apellidos);
       listaDeUsuarios.add(noAfiliado);
       JOptionPane.showMessageDialog(null, "Usuario registrado, ya puede iniciar sesión con sus credenciales.");
    }

    public ArrayList<Usuario> getListaDeUsuarios() {
        return listaDeUsuarios;
    }

    public Pelicula[] getListaDePeliculas() {
        return listaDePeliculas;
    }

    public Sala[] getListaDeSalas() {
        return listaDeSalas;
    }

    public String[] getNombresPeliculas() {
        return nombresPeliculas;
    }

    public Funcion[] getListaFunciones() {
        return listaFunciones;
    }

    public Login getLogin() {
        return login;
    }

    public Image getFondo() {
        return fondo;
    }
    
    
    
    public boolean validarUserName(String username){
        boolean existe = false;
            for (int i = 0; i < listaDeUsuarios.size(); i++) {
                if(username.equals(listaDeUsuarios.get(i).getUsuario())){  
                    existe = true;
                    break;
                }
            }
        return existe;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mousePressed(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseExited(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
