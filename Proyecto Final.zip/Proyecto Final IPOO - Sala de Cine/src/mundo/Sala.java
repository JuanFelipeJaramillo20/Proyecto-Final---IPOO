/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package mundo;

import java.util.Arrays;
import javax.swing.JOptionPane;

/**
 *
 * @author juanf
 */
public class Sala {
    
    public char[][] sillas;
    public double valorTiquete;
    public String nombreSala;
    public boolean ocupada;

    public Sala(String nombreSala) {
        this.nombreSala = nombreSala;
        
    }

    public void inicializarSillas(){
        for (int i = 0; i < sillas.length; i++) {
            for (int j = 0; j < sillas[0].length; j++) {
                sillas[i][j] = 'O';
            }
        }
    }

    public boolean isOcupada() {
        return ocupada;
    }

    public void setOcupada(boolean ocupada) {
        this.ocupada = ocupada;
    }
    
    
    
    public String getNombreSala() {
        return nombreSala;
    }

    public void setNombreSala(String nombreSala) {
        this.nombreSala = nombreSala;
    }

    public char[][] getSillas() {
        return sillas;
    }

    public void setSillas(char[][] sillas) {
        this.sillas = sillas;
    }

    public double getValorTiquete() {
        return valorTiquete;
    }

    public void setValorTiquete(double valorTiquete) {
        this.valorTiquete = valorTiquete;
    }
    
    public String mostrarSillas(){
        return Arrays.deepToString(sillas);
    }
    
    public void marcarSilla(int fila, int columna){
            sillas[fila][columna] = 'X';
    }
    
}
