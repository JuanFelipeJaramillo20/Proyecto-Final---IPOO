/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package mundo;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.ImageIcon;


public class Tiquete {


    public Funcion funcionTiquete;
    public int fila;
    public int columna;
    public Image aficheIMG;

    public Tiquete(Funcion funcionTiquete, int fila, int columna) {
        this.funcionTiquete = funcionTiquete;
        this.fila = fila;
        this.columna = columna;
    }
    
    public void generarTiquete(){
        Document tiquete = new Document(PageSize.A4);
        try {
            funcionTiquete.getSala().marcarSilla(fila, columna);
            PdfWriter writer = PdfWriter.getInstance(tiquete, new FileOutputStream("Tiquete.pdf"));
            tiquete.open();
            
            PdfContentByte cb = writer.getDirectContent();
            Graphics g = cb.createGraphicsShapes(PageSize.A4.getWidth(), PageSize.A5.getHeight());
            Font font = new Font("Arial", Font.BOLD + Font.ITALIC, 18);
            g.setFont(font);
            g.setColor(Color.BLACK);
            
            aficheIMG = funcionTiquete.getPelicula().getAfiche().getImage();
            g.drawImage(aficheIMG, 0, 0, 250, 370, null);
            g.drawString("Información de su boleta:", 260, 20);
            g.drawString("Película: " + funcionTiquete.getPelicula().getNombre(), 260, 40);
            g.drawString("Género: " + funcionTiquete.getPelicula().getGenero(), 260, 60);
            g.drawString("Duración: " + funcionTiquete.getPelicula().getDuracion() + " minutos", 260, 80);
            g.drawString("Clasificación: " + funcionTiquete.getPelicula().getClasificacion(), 260, 100);
            g.drawString("Tipo de Función: " + funcionTiquete.getTipoFuncion(), 260, 120);
            g.drawString("Hora de la función: " + funcionTiquete.getHora(), 260, 140);
            Font f1 = new Font("Arial", font.BOLD + font.ITALIC , 12);
            g.setFont(f1);
            g.drawString("Sala: " + funcionTiquete.getSala().getNombreSala(), 260, 160);
            g.drawString("Su silla se encuentra en la fila " + (fila+1) + ", columna "+ (columna+1), 260, 180   );
            
            tiquete.addTitle("Tiquete - Cinema Univalle");
            tiquete.close();
            
            
        } catch (DocumentException de) {
            System.err.println(de.getMessage());
        } catch (IOException ioe) {
            System.err.println(ioe.getMessage());
        }
    }
    
    
}
