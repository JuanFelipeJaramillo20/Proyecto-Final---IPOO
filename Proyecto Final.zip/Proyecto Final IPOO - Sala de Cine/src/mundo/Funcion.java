/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package mundo;

import java.util.Date;

public class Funcion {

    private Pelicula pelicula;
    private String hora;
    private String tipoFuncion;
    private Sala sala;

    public Funcion(Pelicula pelicula, String hora, Sala sala) {
        this.pelicula = pelicula;
        this.hora = hora;
        this.sala = sala;
    }

    public Sala getSala() {
        return sala;
    }

    public void setSala(Sala sala) {
        this.sala = sala;
    }

    public Pelicula getPelicula() {
        return pelicula;
    }

    public void setPelicula(Pelicula pelicula) {
        this.pelicula = pelicula;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    @Override
    public String toString() {
        return "Funcion{" + "pelicula=" + pelicula.getNombre() + ", hora=" + hora + ", tipoFuncion=" + tipoFuncion + ", sala=" + sala + '}';
    }
    
    

    public String getTipoFuncion() {
        return tipoFuncion;
    }

    public void setTipoFuncion(String tipoFuncion) {
        this.tipoFuncion = tipoFuncion;
    }
}
