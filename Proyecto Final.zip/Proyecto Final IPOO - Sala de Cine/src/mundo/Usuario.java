/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package mundo;

import java.awt.Image;
import java.util.Date;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import java.awt.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import java.awt.Color;
import java.awt.Graphics;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.event.DocumentListener;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Element;
import javax.swing.text.Position;
import javax.swing.text.Segment;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


/**
 *
 * @author juanf
 */
public class Usuario {
    
    public String usuario;
    public String password;
    public String nombre;
    public String apellido;

    public Usuario(String usuario, String password, String nombre, String apellido) {
        this.usuario = usuario;
        this.password = password;
        this.nombre = nombre;
        this.apellido = apellido;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    
    public void registrarPelicula(String nombre, String genero, int duracion, String clasificacion, String sinapsis, String trailer, ImageIcon afiche){
        Pelicula peli = new Pelicula(nombre, genero, duracion, clasificacion, sinapsis, trailer, afiche);
    }
    
    public Supervisor crearSupervisor(String usuario, String password, String nombbre, String apellido){
        Supervisor user = new Supervisor(usuario, password, nombre, apellido);
        return user;
    }
    
    public Afiliado crearAfiliado(String usuario, String password, String nombbre, String apellido){
        Afiliado user = new Afiliado(usuario, password, nombre, apellido);
        return user;
    }
    
    public NoAfiliado crearNoAfiliado(String usuario, String password, String nombbre, String apellido){
        NoAfiliado user = new NoAfiliado(usuario, password, nombre, apellido);
        return user;
    }
    
    public void consultarPeliculasEnCartelera(Pelicula[] listaPeliculas){
        for (int i = 0; i < listaPeliculas.length; i++) {
            ImageIcon afiche = listaPeliculas[i].getAfiche();
            JOptionPane.showMessageDialog(null, listaPeliculas[i].mostrarInfoPelicula(), "Película No. " + (i+1), JOptionPane.INFORMATION_MESSAGE, afiche);
        }
    }
    
    public void reservarTiquete(Funcion funcion, int fila, int columna, int codigoReserva){
        Reserva reserva = new Reserva(funcion, fila, columna, codigoReserva);
        reserva.generarReserva(this);
    }
    
    public void comprarTiquete(Funcion funcion, int fila, int columna){
        Tiquete boleta = new Tiquete(funcion, fila, columna);
        boleta.generarTiquete();
    }
    
    public Funcion crearFuncion(Pelicula pelicula, String hora, Sala sala){
        Funcion funcion = new Funcion(pelicula, hora, sala);
        return funcion;
    }
    
    public void modificarNombres(){
        nombre = Utilerias.leerString("Ingrese el nuevo nombre");
    }
    
    public void modificarApellidos(){
        apellido = Utilerias.leerString("Ingrese los nuevos apellidos:");
    }
    
    public void modificarUserName(){
        usuario = Utilerias.leerString("Ingrese el nuevo nombre de usuario:");
    }
    
    public void modificarContrasena(){
        this.password = Utilerias.leerString("Ingrese la contraseña nueva:");
    }
}
