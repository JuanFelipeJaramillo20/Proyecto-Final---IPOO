/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package mundo;

public class Afiliado extends Usuario{

    public Afiliado(String usuario, String password, String nombre, String apellido) {
        super(usuario, password, nombre, apellido);
    }
    
}
