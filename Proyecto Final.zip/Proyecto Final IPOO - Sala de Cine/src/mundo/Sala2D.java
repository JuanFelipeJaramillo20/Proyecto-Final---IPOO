/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package mundo;


public class Sala2D extends Sala {

    public Sala2D(String nombreSala) {
        super(nombreSala);
        valorTiquete = 7500;
        sillas = new char[8][10];
        inicializarSillas();
    }
    
}
