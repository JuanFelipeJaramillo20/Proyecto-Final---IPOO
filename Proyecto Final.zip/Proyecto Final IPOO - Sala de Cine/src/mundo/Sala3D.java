/*
 * Juan Felipe Jaramillo Losada - 202060257
 * Introducción a la programación orientada a objetos - IPOO
 * Universidad del Valle
 */
package mundo;


public class Sala3D extends Sala{

    public Sala3D(String nombreSala) {
        super(nombreSala);
        valorTiquete = 9500;
        sillas = new char[8][6];
        inicializarSillas();
    }

    @Override
    public void inicializarSillas() {
        super.inicializarSillas(); 
        sillas[7][2] = 'X';
        sillas[7][3] = 'X';
        sillas[7][4] = 'X';
        sillas[7][5] = 'X';
    }
    
    
}
